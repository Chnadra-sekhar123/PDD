<?php
// Enable CORS for local development
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

// Database configuration
include 'config.php';

// Handle OPTIONS request for CORS preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Get the input data
$input = file_get_contents("php://input");
$data = json_decode($input, true);

// Validate input data
if (!isset($data['type']) || !isset($data['brand']) || !isset($data['model']) || 
    empty($data['type']) || empty($data['brand']) || empty($data['model'])) {
    echo json_encode([
        "status" => "error",
        "message" => "Invalid input. Please provide type, brand, and model."
    ]);
    exit();
}

// Sanitize input data
$type = $conn->real_escape_string($data['type']);
$brand = $conn->real_escape_string($data['brand']);
$model = $conn->real_escape_string($data['model']);

// Insert data into the deviceinfo table
$sql = "INSERT INTO deviceinfo (type, brand, model) VALUES ('$type', '$brand', '$model')";

if ($conn->query($sql) === TRUE) {
    echo json_encode([
        "status" => "success",
        "message" => "Device request submitted successfully."
    ]);
} else {
    echo json_encode([
        "status" => "error",
        "message" => "Failed to submit device request: " . $conn->error
    ]);
}

// Close the database connection
$conn->close();
?>
