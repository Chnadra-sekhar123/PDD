import 'dart:async';
import 'package:flutter/services.dart';

/// A custom FlutterBlue-like class for managing Bluetooth connections
class CustomFlutterBlue {
  static const MethodChannel _channel = MethodChannel('flutter_blue_channel');

  /// Stream for scanning results
  final StreamController<Map<String, dynamic>> _scanResultsController =
      StreamController.broadcast();

  /// Singleton instance
  static final CustomFlutterBlue instance = CustomFlutterBlue._();

  CustomFlutterBlue._();

  /// Start scanning for Bluetooth devices
  Future<void> startScan(
      {Duration timeout = const Duration(seconds: 10)}) async {
    try {
      _scanResultsController.addStream(_scanNativeDevices(timeout));
    } on PlatformException catch (e) {
      print('Failed to start scan: ${e.message}');
    }
  }

  /// Stop scanning for Bluetooth devices
  Future<void> stopScan() async {
    try {
      await _channel.invokeMethod('stopScan');
    } catch (e) {
      print('Failed to stop scan: $e');
    }
  }

  /// Connect to a Bluetooth device
  Future<void> connect(String deviceId) async {
    try {
      await _channel.invokeMethod('connect', {'deviceId': deviceId});
    } catch (e) {
      print('Failed to connect to device: $e');
    }
  }

  /// Disconnect from a Bluetooth device
  Future<void> disconnect(String deviceId) async {
    try {
      await _channel.invokeMethod('disconnect', {'deviceId': deviceId});
    } catch (e) {
      print('Failed to disconnect from device: $e');
    }
  }

  /// Discover services of a connected device
  Future<List<Map<String, dynamic>>> discoverServices(String deviceId) async {
    try {
      final List<dynamic> services = await _channel
          .invokeMethod('discoverServices', {'deviceId': deviceId});
      return services.cast<Map<String, dynamic>>();
    } catch (e) {
      print('Failed to discover services: $e');
      return [];
    }
  }

  /// Listen for scan results
  Stream<Map<String, dynamic>> get scanResults => _scanResultsController.stream;

  /// Scan devices via the native platform
  Stream<Map<String, dynamic>> _scanNativeDevices(Duration timeout) async* {
    try {
      final List<dynamic> devices = await _channel.invokeMethod('startScan', {
        'timeout': timeout.inSeconds,
      });
      for (final device in devices) {
        yield Map<String, dynamic>.from(device);
      }
    } catch (e) {
      print('Failed to scan devices: $e');
    }
  }
}
