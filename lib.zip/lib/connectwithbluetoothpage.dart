import 'package:flutter/material.dart';

class ConnectWithBluetoothPage extends StatefulWidget {
  const ConnectWithBluetoothPage({Key? key}) : super(key: key);

  @override
  State<ConnectWithBluetoothPage> createState() =>
      _ConnectWithBluetoothPageState();
}

class _ConnectWithBluetoothPageState extends State<ConnectWithBluetoothPage> {
  bool isBluetoothOn = false; // Variable to track Bluetooth state

  @override
  void initState() {
    super.initState();
    checkBluetoothState();
  }

  // Check initial Bluetooth state
  void checkBluetoothState() {
    setState(() {
      isBluetoothOn = false; // Default state for simulation
    });
  }

  // Toggle Bluetooth state
  void toggleBluetooth() {
    setState(() {
      isBluetoothOn = !isBluetoothOn;
    });

    if (isBluetoothOn) {
      print("Bluetooth turned ON");
    } else {
      print("Bluetooth turned OFF");
    }
  }

  // Handle Next button press
  void handleNextButton() {
    if (!isBluetoothOn) {
      // Show pop-up dialog if Bluetooth is off
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Bluetooth is Off'),
          content: const Text('Please turn on Bluetooth to proceed.'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context), // Close the dialog
              child: const Text('OK'),
            ),
          ],
        ),
      );
    } else {
      // Proceed to the next page
      print("Proceeding to the next page...");
      // Add navigation logic here if required
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Connect via Bluetooth'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Display Bluetooth status
            Text(
              isBluetoothOn ? "Bluetooth is ON" : "Bluetooth is OFF",
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 20),
            // Toggle button
            ElevatedButton(
              onPressed: toggleBluetooth, // Call toggleBluetooth on press
              style: ElevatedButton.styleFrom(
                backgroundColor: isBluetoothOn ? Colors.blue : Colors.grey,
                foregroundColor: Colors.white,
                padding:
                    const EdgeInsets.symmetric(horizontal: 40, vertical: 20),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20),
                ),
              ),
              child: Text(
                  isBluetoothOn ? "Turn OFF Bluetooth" : "Turn ON Bluetooth"),
            ),
            const SizedBox(height: 40),
            // Next button
            ElevatedButton(
              onPressed: handleNextButton, // Call handleNextButton on press
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green,
                foregroundColor: Colors.white,
                padding:
                    const EdgeInsets.symmetric(horizontal: 40, vertical: 20),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20),
                ),
              ),
              child: const Text("Next"),
            ),
          ],
        ),
      ),
    );
  }
}
 