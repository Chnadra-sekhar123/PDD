import 'dart:convert'; // For jsonEncode
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

// ignore: must_be_immutable
class DeviceInfoPage extends StatelessWidget {
  final TextEditingController brandController = TextEditingController();
  final TextEditingController modelController = TextEditingController();
  String selectedType = "Smart TV"; // Default selected type

  DeviceInfoPage({super.key}); // Constructor

  // Function to submit the device info to the PHP server
  Future<void> submitRequest(BuildContext context) async {
    // Check if any of the fields are empty
    if (brandController.text.isEmpty || modelController.text.isEmpty) {
      // Show a popup if any field is empty
      _showErrorDialog(context, 'Please enter both the brand and model.');
      return;
    }

    // Prepare the data to send
    Map<String, String> data = {
      'type': selectedType,
      'brand': brandController.text,
      'model': modelController.text,
    };

    print('Request Data: $data'); // Debug log

    try {
      final response = await http.post(
        Uri.parse(
            'http://192.168.180.163/remoteapp/deviceinfo.php'), // Replace with your PHP server's URL
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(data),
      );

      print('Response Status: ${response.statusCode}');
      print('Response Body: ${response.body}');

      if (response.statusCode == 200) {
        final responseData = jsonDecode(response.body);
        if (responseData['status'] == 'success') {
          // Navigate to the RequestSubmitPage on success
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const RequestSubmitPage()),
          );
        } else {
          _showErrorDialog(context, responseData['message']);
        }
      } else {
        _showErrorDialog(context, 'Failed to submit data. Please try again.');
      }
    } catch (e) {
      print('Error: $e'); // Debug log
      _showErrorDialog(context, 'An error occurred. Please try again later.');
    }
  }

  // Function to show error dialog
  void _showErrorDialog(BuildContext context, String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Error'),
        content: Text(message),
        actions: <Widget>[
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
            },
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Device Info"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const Icon(
                Icons.sentiment_dissatisfied,
                size: 100,
                color: Colors.grey,
              ),
              const SizedBox(height: 16),
              const Text(
                "Couldn't get the device info",
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 8),
              const Text(
                "Can't pair the device",
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                  color: Colors.black54,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 16),
              const Text(
                "Send us details about this device\nso that we can support it later on",
                style: TextStyle(
                  fontSize: 14,
                  color: Colors.black54,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 24),
              Container(
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.grey),
                  borderRadius: BorderRadius.circular(8),
                ),
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    DropdownButtonFormField<String>(
                      value: selectedType,
                      decoration: const InputDecoration(
                        labelText: "Type",
                        border: InputBorder.none,
                      ),
                      items: ["Smart TV", "Smart Fan", "AC", "Setup Box"]
                          .map((type) {
                        return DropdownMenuItem<String>(
                          value: type,
                          child: Text(type),
                        );
                      }).toList(),
                      onChanged: (newValue) {
                        selectedType = newValue!;
                      },
                    ),
                    const Divider(),
                    TextField(
                      controller: brandController,
                      decoration: const InputDecoration(
                        labelText: "Brand",
                        hintText: "Enter device brand",
                        border: InputBorder.none,
                      ),
                    ),
                    const Divider(),
                    TextField(
                      controller: modelController,
                      decoration: const InputDecoration(
                        labelText: "Model",
                        hintText: "Enter device model",
                        border: InputBorder.none,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),
              ElevatedButton(
                onPressed: () => submitRequest(context),
                child: const Text("Submit"),
                style: ElevatedButton.styleFrom(
                  minimumSize: const Size(double.infinity, 48),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class RequestSubmitPage extends StatelessWidget {
  const RequestSubmitPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Request Submitted"),
        automaticallyImplyLeading: false,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(
                Icons.check_circle,
                color: Colors.green,
                size: 100,
              ),
              const SizedBox(height: 24),
              const Text(
                "Request Submitted Successfully!",
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 16),
              const Text(
                "Our team will review the details and\nadd support for this device soon.",
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.black54,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 32),
              ElevatedButton(
                onPressed: () {
                  Navigator.popUntil(context, (route) => route.isFirst);
                },
                child: const Text("Go Back to Home"),
                style: ElevatedButton.styleFrom(
                  minimumSize: const Size(double.infinity, 48),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
